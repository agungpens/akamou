
<!-- Navbar pills -->
<div class="row">
    <div class="col-md-12">
      <ul class="nav nav-pills flex-column flex-sm-row mb-4 nav-data">
        <li class="nav-item"><a onclick="Navigate.getPage(this, event)" class="nav-link active" href="" data-target="profile-details"><i class='bx bx-user'></i> Profile</a></li>
        <li class="nav-item"><a onclick="Navigate.getPage(this, event)" class="nav-link" href="" data-target="mutasi-details"><i class='bx bx-group'></i> Mutasi</a></li>
        <li class="nav-item"><a onclick="Navigate.getPage(this, event)" class="nav-link" href="" data-target="pendidikan-details"><i class='bx bxs-graduation' ></i> Pendidikan</a></li>
        <li class="nav-item"><a onclick="Navigate.getPage(this, event)" class="nav-link" href="" data-target="keluarga-details"><i class='bx bx-group' ></i> Keluarga</a></li>
        <li class="nav-item"><a onclick="Navigate.getPage(this, event)" class="nav-link" href="" data-target="riwayatkerja-details"><i class='bx bx-info-circle' ></i> Riwayat Pekerjaan</a></li>
        <li class="nav-item"><a onclick="Navigate.getPage(this, event)" class="nav-link" href="" data-target="riwayatorganisasi-details"><i class='bx bx-info-circle' ></i> Riwayat Organisasi</a></li>
        <li class="nav-item"><a onclick="Navigate.getPage(this, event)" class="nav-link" href="" data-target="training-details"><i class='bx bx-link-alt'></i> Training</a></li>
        <li class="nav-item"><a onclick="Navigate.getPage(this, event)" class="nav-link" href="" data-target="outstanding-details"><i class='bx bx-food-menu'></i> Outstanding Pengajuan</a></li>
        <li class="nav-item"><a onclick="Navigate.getPage(this, event)" class="nav-link" href="" data-target="absensi-details"><i class='bx bx-food-menu'></i> Absensi</a></li>
      </ul>
    </div>
  </div>
  <!--/ Navbar pills --><?php /**PATH E:\laragon\www\LARAVEL\akamou\resources\views/web/profile/navigation.blade.php ENDPATH**/ ?>