<!-- About User -->
<div class="card mb-4">
    <div class="card-body">
      <small class="text-muted text-uppercase">About</small>
      <ul class="list-unstyled mb-4 mt-3">
        <li class="d-flex align-items-center mb-3"><i class="bx bx-user"></i><span class="fw-semibold mx-2">Nama:</span> <span><?php echo e($info->nama_lengkap); ?></span></li>
        <li class="d-flex align-items-center mb-3"><i class='bx bxs-calendar'></i><span class="fw-semibold mx-2">Tanggal Lahir:</span> <span><?php echo e(date('d-M-Y',strtotime($info->tgl_lahir))); ?></span></li>
        <li class="d-flex align-items-center mb-3"><i class="bx bx-check"></i><span class="fw-semibold mx-2">Status:</span> <span><?php echo e($info->status_karyawan); ?></span></li>
        <li class="d-flex align-items-center mb-3"><i class="bx bx-star"></i><span class="fw-semibold mx-2">Jabatan:</span> <span><?php echo e($info->jobgrade); ?></span></li>
        <li class="d-flex align-items-center mb-3"><i class="bx bx-star"></i><span class="fw-semibold mx-2">Departemen:</span> <span><?php echo e($info->nama_departemen); ?></span></li>
        
      </ul>
      <small class="text-muted text-uppercase">Contacts</small>
      <ul class="list-unstyled mb-4 mt-3">
        <li class="d-flex align-items-center mb-3"><i class="bx bx-phone"></i><span class="fw-semibold mx-2">Contact:</span> <span><?php echo e($info->telp_hp); ?></span></li>
        <li class="d-flex align-items-center mb-3"><i class='bx bx-map' ></i><span class="fw-semibold mx-2">Alamat</span> <span class="text-wrap"><?php echo e($info->domisili_alamat); ?></span></li>
        <li class="d-flex align-items-center mb-3"><i class="bx bx-envelope"></i><span class="fw-semibold mx-2">Email:</span> <span><?php echo e(empty($info->email) ? '-' : $info->email); ?></span></li>
      </ul>
      
    </div>
  </div>
  <!--/ About User --><?php /**PATH E:\laragon\www\LARAVEL\akamou\resources\views/web/profile/aboutuser.blade.php ENDPATH**/ ?>