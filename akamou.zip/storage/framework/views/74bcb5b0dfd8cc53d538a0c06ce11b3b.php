<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<body>
    <div class="layout-wrapper layout-content-navbar">
        <div class="loader"></div>
        <div class="layout-container">
            <div class="toast-content"></div>
            <?php echo $__env->make('template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="layout-page">
                <?php echo $__env->make('template.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="content-wrapper">
                    <div class="container-fluid flex-grow-1 container-p-y">
                        <?php echo $__env->make('template.breadcumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo isset($view_file) ? $view_file : ''; ?>

                    </div>
                    <div class="content-backdrop fade"></div>
                    <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>

        </div>
    </div>

    <div id="template-customizer"></div>
    <!-- / Layout wrapper -->
    <?php echo $__env->make('template.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
    <?php if(isset($js)): ?>
        <script src="<?php echo e(asset($js)); ?>"></script>
    <?php endif; ?>
</body>

</html>
<?php /**PATH E:\laragon\www\LARAVEL\akamou\resources\views/template/main.blade.php ENDPATH**/ ?>