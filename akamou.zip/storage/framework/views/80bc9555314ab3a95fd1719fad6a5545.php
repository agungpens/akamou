
<?php /**PATH E:\laragon\www\LARAVEL\akamou\resources\views/page/dashboard.blade.php ENDPATH**/ ?>