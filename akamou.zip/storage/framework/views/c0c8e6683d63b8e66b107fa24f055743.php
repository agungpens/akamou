
<!-- User Profile Content -->
<div class="row">
    <div class="col-xl-4 col-lg-5 col-md-5">
      <?php echo $__env->make('web.profile.aboutuser', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <?php echo $__env->make('web.profile.profileoverview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-xl-8 col-lg-7 col-md-7">
      <?php echo $__env->make('web.profile.activitytimeline', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      <div class="row">
        
        <!-- Teams -->
        
        <!--/ Teams -->
      </div>
      <?php echo $__env->make('web.profile.dataproject', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
  <!--/ User Profile Content --><?php /**PATH E:\laragon\www\LARAVEL\akamou\resources\views/web/profile/usercontent.blade.php ENDPATH**/ ?>