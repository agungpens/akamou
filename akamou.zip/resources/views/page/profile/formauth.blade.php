<div class="card">
    <div class="card-body">
        halaman auth
    </div>
</div>
