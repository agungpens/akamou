let Mahasiswa = {
    
}