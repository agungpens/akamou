let Mahasiswa = {
    
}