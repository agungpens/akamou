

let ScheduleDetail = {
    module: () => {
        return "jadwal-driver/schedule-detail";
    },

    moduleApi: () => {
        return `api/${ScheduleDetail.module()}`;
    },
    moduleSchedule: () => {
        return "jadwal-driver/schedule";
    },

    moduleScheduleApi: () => {
        return `api/${ScheduleDetail.moduleSchedule()}`;
    },
    moduleTemplate: () => {
        return "jadwal-driver/template-pekerjaan_detail";
    },

    moduleTemplateApi: () => {
        return `api/${ScheduleDetail.moduleTemplate()}`;
    },

    add: () => {
        window.location.href = url.base_url(ScheduleDetail.module()) + "add";
    },

    ubah: (elm) => {
        let data_id = $(elm).attr("data_id");
        window.location.href = url.base_url(ScheduleDetail.module()) + "ubah?id=" + data_id;
    },

    back: () => {
        window.location.href = url.base_url(ScheduleDetail.module()) + "index";
    },

    getData: async () => {
        let tableData = $('table#table-data');

        if (tableData.length > 0) {
            tableData.DataTable({
                "processing": true,
                "serverSide": true,
                "ordering": true,
                "autoWidth": false,
                "order": [
                    [0, 'desc']
                ],
                "aLengthMenu": [
                    [25, 50, 100],
                    [25, 50, 100]
                ],
                "ajax": {
                    "url": url.base_url(ScheduleDetail.moduleApi()) + `getData`,
                    "type": "POST",
                },
                "deferRender": true,
                "createdRow": function (row, data, dataIndex) {
                },
                "columnDefs": [{
                    "targets": 2,
                    "orderable": false,
                    "createdCell": function (td, cellData, rowData, row, col) {
                        $(td).addClass('text-center');
                    }
                },
                ],
                "columns": [{
                    "data": "id",
                    render: function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                },
                {
                    "data": "schedule_id",
                },
                {
                    "data": "template",
                },
                {
                    "data": "template_pekerjaan_nama",
                },
                {
                    "data": "template_pekerjaan_todo",
                },
                {
                    "data": "schedule_detail_dokumentasi_ids",
                },
                {
                    "data": "id",
                    "render": (data, type, row, meta) => {
                        return `
                            <i class="bx bx-edit" style="cursor: pointer;" data_id="${data}" onclick="ScheduleDetail.ubah(this)"></i>
                            <i class="bx bx-trash" style="cursor: pointer;" data_id="${data}" onclick="ScheduleDetail.delete(this, event)"></i>`;
                    }
                }
                ]
            });
        }
    },

    delete: (elm, e) => {
        e.preventDefault();
        let data_id = $(elm).attr('data_id');
        let html = `<div class="row g-3">
        <div class="col-12">
        <hr/>
        </div>
        <div class="col-12 text-center">
            <p>Apakah anda yakin akan menghapus data ini ?</p>
        </div>
        <div class="col-12 text-center">
            <br/>
            <button class="btn btn-primary btn-sm" onclick="ScheduleDetail.deleteConfirm(this, '${data_id}')">Ya</button>
            <button class="btn btn-sm" onclick="message.closeDialog()">Tidak</button>
        </div>
        </div>`;

        bootbox.dialog({
            message: html
        });


    },

    deleteConfirm: (elm, id) => {
        let params = {};
        params.id = id;
        $.ajax({
            type: 'POST',
            dataType: 'json',
            data: params,
            url: url.base_url(ScheduleDetail.moduleApi()) + "delete",

            beforeSend: () => {
                message.loadingProses('Proses Hapus Data');
            },

            error: function () {
                message.closeLoading();
                Toast.error('Informasi', "Gagal");
            },

            success: function (resp) {
                message.closeLoading();
                if (resp.is_valid) {
                    Toast.success('Informasi', 'Data Berhasil Dihapus');
                    setTimeout(function () {
                        window.location.reload();
                    }, 1000);
                } else {
                    Toast.error('Informasi', 'Data Gagal Dihapus ', resp.message);
                }
            }
        });
    },

    getPostInputDokumen: () => {
        let params = {};
        let data_file = $('div.content-file-upload');
        $.each(data_file, function () {
            let $this = $(this);
            let attr_obj_img = $this.find('img').attr('id');
            let attr_obj_filename = $this.find('label').attr('id');
            params[`${attr_obj_img.replaceAll('-', '_')}`] = $this.find('img').attr('src');
            params[`${attr_obj_filename.replaceAll('-', '_')}`] = $this.find('label').text().trim();
        });

        return params;
    },

    getPostData: () => {
        let data = {
            'data': {
                'id': $('input#id').val(),
                'schedule_id': $.trim($('#schedule_id').val()),
                'template_pekerjaan_id': $.trim($('#template_pekerjaan_id').val()),
                'template_pekerjaan_nama': $.trim($('#template_pekerjaan_nama').val()),
                'template_pekerjaan_todo': $.trim($('#template_pekerjaan_todo').val()),
                'schedule_detail_dokumentasi_ids': $.trim($('#schedule_detail_dokumentasi_ids').val()),
            },
        };
        return data;
    },

    submit: (elm, e) => {
        e.preventDefault();
        let params = ScheduleDetail.getPostData();
        let form = $(elm).closest('div.row');
        if (validation.runWithElement(form)) {
            $.ajax({
                type: 'POST',
                dataType: 'json',
                data: params,
                url: url.base_url(ScheduleDetail.moduleApi()) + "submit",
                beforeSend: () => {
                    message.loadingProses('Proses Simpan Data...');
                },
                error: function () {
                    message.closeLoading();
                    Toast.error('Informasi', "Gagal");
                },

                success: function (resp) {
                    message.closeLoading();
                    if (resp.is_valid) {
                        Toast.success('Informasi', 'Data Berhasil Disimpan');
                        setTimeout(function () {
                            window.location.reload();
                        }, 1000);
                    } else {
                        bootbox.dialog({
                            message: resp.message
                        });
                    }
                }
            });
        }
    },




    setDate: () => {
        const flatpickrRange = document.querySelector('.flatpickr');
        if (flatpickrRange) {
            flatpickrRange.flatpickr();
        }
    },

    select2All: () => {
        // Default
        const select2 = $('.select2');
        if (select2.length) {
            select2.each(function () {
                var $this = $(this);
                $this.wrap('<div class="position-relative"></div>').select2({
                    placeholder: 'Select value',
                    dropdownParent: $this.parent()
                });
            });
        }
    },


    showDataSchedule: (elm) => {
        let params = {};

        $.ajax({
            type: 'POST',
            dataType: 'html',
            data: params,
            url: url.base_url(ScheduleDetail.moduleApi()) + "showDataSchedule",

            beforeSend: () => {
                message.loadingProses('Proses Pengambilan Data');
            },

            error: function () {
                message.closeLoading();
                Toast.error("Informasi", "Gagal");
            },

            success: function (resp) {
                message.closeLoading();
                bootbox.dialog({
                    message: resp,
                    size: 'large'
                });
                ScheduleDetail.getDataSchedule();
            }
        });
    },

    getDataSchedule: async () => {
        let tableData = $('table#table-data-schedule');
        let params = {};
        params.id = $('#id').val();
        if (tableData.length > 0) {
            tableData.DataTable({
                "processing": true,
                "serverSide": true,
                "ordering": true,
                "autoWidth": false,
                "order": [
                    [0, 'desc']
                ],
                "aLengthMenu": [
                    [200, 300, 1000],
                    [200, 300, 1000]
                ],
                "ajax": {
                    "url": url.base_url(ScheduleDetail.moduleScheduleApi()) + `getData`,
                    "type": "POST",
                    "data": params
                    // "headers": {
                    //     'X-CSRF-TOKEN': `'${tokenApi}'`
                    // }
                },
                "deferRender": true,
                "createdRow": function (row, data, dataIndex) {
                    // console.log('row', $(row));
                },
                "columnDefs": [{
                    "targets": 3,
                    "orderable": false,
                    "createdCell": function (td, cellData, rowData, row, col) {
                        $(td).addClass('text-center');
                        $(td).addClass('td-padd');
                        $(td).addClass('action');
                    }
                },
                {
                    "targets": 2,
                    "orderable": false,
                    "createdCell": function (td, cellData, rowData, row, col) {
                        $(td).addClass('td-padd');
                    }
                },
                {
                    "targets": 1,
                    "orderable": false,
                    "createdCell": function (td, cellData, rowData, row, col) {
                        $(td).addClass('td-padd');
                    }
                },
                {
                    "targets": 0,
                    "createdCell": function (td, cellData, rowData, row, col) {
                        $(td).addClass('td-padd');
                        $(td).addClass('text-center');
                    }
                },
                ],
                "columns": [{
                    "data": "id",
                    render: function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                },
                {
                    "data": "driver",
                },
                {
                    "data": "tanggal",
                },
                {
                    "data": "start",
                },
                {
                    "data": "end",
                },
                {
                    "data": "menit",
                },
                {
                    "data": "template",
                },
                {
                    "data": "id",
                    "render": (data, type, row, meta) => {
                        return `<i class="bx bx-edit" style="cursor: pointer;" driver="${row.driver}" data_id="${data}" onclick="ScheduleDetail.pilihDataSchedule(this)"></i>`;
                    }
                }
                ]
            });
        }
    },

    pilihDataSchedule: (elm) => {
        let driver = $(elm).attr('driver');
        let id = $(elm).attr('data_id');
        $('#schedule_id').val(id + " - " + driver);
        message.closeDialog();
    },

    setNikSchedule: (elm, e) => {
        let schedule_id = $(elm).is(':checked') ? $(elm).attr('schedule_id') : '';
        $('#schedule_id').val(schedule_id);
    },


    showDataTemplate: (elm) => {
        let params = {};

        $.ajax({
            type: 'POST',
            dataType: 'html',
            data: params,
            url: url.base_url(ScheduleDetail.moduleApi()) + "showDataTemplate",

            beforeSend: () => {
                message.loadingProses('Proses Pengambilan Data');
            },

            error: function () {
                message.closeLoading();
                Toast.error("Informasi", "Gagal");
            },

            success: function (resp) {
                message.closeLoading();
                bootbox.dialog({
                    message: resp,
                    size: 'large'
                });
                ScheduleDetail.getDataTemplate();
            }
        });
    },

    getDataTemplate: async () => {
        let tableData = $('table#table-data-template');
        let params = {};
        params.id = $('#id').val();
        if (tableData.length > 0) {
            tableData.DataTable({
                "processing": true,
                "serverSide": true,
                "ordering": true,
                "autoWidth": false,
                "order": [
                    [0, 'desc']
                ],
                "aLengthMenu": [
                    [200, 300, 1000],
                    [200, 300, 1000]
                ],
                "ajax": {
                    "url": url.base_url(ScheduleDetail.moduleTemplateApi()) + `getData`,
                    "type": "POST",
                    "data": params
                    // "headers": {
                    //     'X-CSRF-TOKEN': `'${tokenApi}'`
                    // }
                },
                "deferRender": true,
                "createdRow": function (row, data, dataIndex) {
                    // console.log('row', $(row));
                },
                "columnDefs": [{
                    "targets": 3,
                    "orderable": false,
                    "createdCell": function (td, cellData, rowData, row, col) {
                        $(td).addClass('text-center');
                        $(td).addClass('td-padd');
                        $(td).addClass('action');
                    }
                },
                {
                    "targets": 2,
                    "orderable": false,
                    "createdCell": function (td, cellData, rowData, row, col) {
                        $(td).addClass('td-padd');
                    }
                },
                {
                    "targets": 1,
                    "orderable": false,
                    "createdCell": function (td, cellData, rowData, row, col) {
                        $(td).addClass('td-padd');
                    }
                },
                {
                    "targets": 0,
                    "createdCell": function (td, cellData, rowData, row, col) {
                        $(td).addClass('td-padd');
                        $(td).addClass('text-center');
                    }
                },
                ],
                "columns": [{
                    "data": "id",
                    render: function (data, type, row, meta) {
                        return meta.row + meta.settings._iDisplayStart + 1;
                    }
                },
                {
                    "data": "template",
                },
                {
                    "data": "nama",
                },
                {
                    "data": "todo",
                },
                {
                    "data": "nama_dokumen",
                },
                {
                    "data": "id",
                    "render": (data, type, row, meta) => {
                        return `<i class="bx bx-edit" style="cursor: pointer;" template_pekerjaan_nama="${row.nama}" template_pekerjaan_todo="${row.todo}" data_id="${data}" onclick="ScheduleDetail.pilihDataTemplate(this)"></i>`;
                    }
                }
                ]
            });
        }
    },

    pilihDataTemplate: (elm) => {
        let template_pekerjaan_nama = $(elm).attr('template_pekerjaan_nama');
        let template_pekerjaan_todo = $(elm).attr('template_pekerjaan_todo');
        let id = $(elm).attr('data_id');
        $('#template_pekerjaan_id').val(id);
        $('#template_pekerjaan_nama').val(template_pekerjaan_nama);
        $('#template_pekerjaan_todo').val(template_pekerjaan_todo);
        message.closeDialog();
    },

    setNikTemplate: (elm, e) => {
        let template_pekerjaan_id = $(elm).is(':checked') ? $(elm).attr('template_pekerjaan_id') : '';
        $('#template_pekerjaan_id').val(template_pekerjaan_id);
    },


};

$(function () {
    ScheduleDetail.getData();
    ScheduleDetail.getDataSchedule();
    ScheduleDetail.getDataTemplate();
    ScheduleDetail.select2All();
});
